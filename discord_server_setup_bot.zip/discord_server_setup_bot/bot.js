require("dotenv").config();
const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder, ChannelType, PermissionFlagsBits } = require("discord.js");
const token = process.env.DISCORD_TOKEN, clientId = process.env.CLIENT_ID;
if (!token || !clientId) { console.error("Add DISCORD_TOKEN and CLIENT_ID to .env"); process.exit(1); }
const client = new Client({ intents: [GatewayIntentBits.Guilds] });
const commands = [
 new SlashCommandBuilder().setName("setup").setDescription("Create starter server channels and roles").setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild).toJSON(),
 new SlashCommandBuilder().setName("help").setDescription("Show bot commands").toJSON()
];
async function register() { const rest = new REST({version:"10"}).setToken(token); await rest.put(Routes.applicationCommands(clientId), {body:commands}); }
async function role(guild, name, color, permissions=[]) {
 let r = guild.roles.cache.find(x=>x.name===name);
 if (!r) r = await guild.roles.create({name,color,permissions,reason:"Discord server setup"});
 return r;
}
async function category(guild, name) {
 let c = guild.channels.cache.find(x=>x.type===ChannelType.GuildCategory && x.name===name);
 if (!c) c = await guild.channels.create({name,type:ChannelType.GuildCategory,reason:"Discord server setup"});
 return c;
}
async function channel(guild, name, type, parent, topic) {
 let c = guild.channels.cache.find(x=>x.name===name && x.type===type && x.parentId===parent.id);
 if (!c) c = await guild.channels.create({name,type,parent:parent.id, ...(topic && type===ChannelType.GuildText ? {topic}:{}),reason:"Discord server setup"});
 return c;
}
async function setup(guild) {
 await role(guild,"Admin","#E74C3C",[PermissionFlagsBits.ManageGuild,PermissionFlagsBits.ManageChannels,PermissionFlagsBits.ManageRoles,PermissionFlagsBits.KickMembers,PermissionFlagsBits.BanMembers,PermissionFlagsBits.ModerateMembers]);
 await role(guild,"Moderator","#3498DB",[PermissionFlagsBits.KickMembers,PermissionFlagsBits.ModerateMembers,PermissionFlagsBits.ManageMessages]);
 await role(guild,"Member","#95A5A6");
 await role(guild,"Muted","#7F8C8D");
 const info=await category(guild,"📌 INFORMATION"), community=await category(guild,"💬 COMMUNITY"), voice=await category(guild,"🔊 VOICE"), staff=await category(guild,"🛡️ STAFF");
 const T=ChannelType.GuildText, V=ChannelType.GuildVoice;
 await channel(guild,"👋・welcome",T,info,"Welcome to the server!");
 await channel(guild,"📜・rules",T,info,"Please read the server rules.");
 await channel(guild,"📢・announcements",T,info,"Official server announcements.");
 await channel(guild,"💭・general-chat",T,community,"Chat with the community.");
 await channel(guild,"📸・media",T,community,"Share images and clips.");
 await channel(guild,"🎮・gaming",T,community,"Talk about games.");
 await channel(guild,"🔊・General Voice",V,voice);
 await channel(guild,"🎮・Gaming Voice",V,voice);
 const everyone=guild.roles.everyone, admin=guild.roles.cache.find(r=>r.name==="Admin"), mod=guild.roles.cache.find(r=>r.name==="Moderator");
 await staff.permissionOverwrites.edit(everyone,{ViewChannel:false});
 if(admin) await staff.permissionOverwrites.edit(admin,{ViewChannel:true});
 if(mod) await staff.permissionOverwrites.edit(mod,{ViewChannel:true});
 await channel(guild,"🔒・staff-chat",T,staff,"Private staff discussion.");
 await channel(guild,"📋・logs",T,staff,"Staff-only notes and logs.");
}
client.once("ready",()=>console.log(`Logged in as ${client.user.tag}`));
client.on("interactionCreate",async i=>{
 if(!i.isChatInputCommand()) return;
 if(i.commandName==="help") return i.reply({content:"`/setup` creates starter channels and roles.\n`/help` shows this message.",ephemeral:true});
 if(i.commandName==="setup") {
  if(!i.inGuild()) return i.reply({content:"Use this command inside your server.",ephemeral:true});
  if(!i.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) return i.reply({content:"You need Manage Server permission.",ephemeral:true});
  await i.deferReply({ephemeral:true});
  try { await setup(i.guild); await i.editReply("✅ Setup complete! Channels, categories, and starter roles were created. Assign roles to members manually. The STAFF category is private to Admin and Moderator."); }
  catch(e) { console.error(e); await i.editReply("❌ Setup failed. Check the bot has Manage Channels and Manage Roles, and move its role above roles it needs to manage."); }
 }
});
(async()=>{try{await register();await client.login(token);}catch(e){console.error(e);process.exit(1);}})();
