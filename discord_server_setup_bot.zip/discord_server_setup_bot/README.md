# Discord Server Setup Bot

This project adds `/setup` and `/help`.

`/setup` creates:
- 📌 INFORMATION: welcome, rules, announcements
- 💬 COMMUNITY: general-chat, media, gaming
- 🔊 VOICE: General Voice, Gaming Voice
- 🛡️ STAFF (private): staff-chat, logs
- Roles: Admin, Moderator, Member, Muted

It does not grant Administrator permission. Assign roles to members manually. Ticket automation and automatic event logging are not included in this starter version.

## Install
1. Install Node.js 20 or newer.
2. Extract the ZIP and run `npm install`.
3. Copy `.env.example` to `.env`.
4. Set `DISCORD_TOKEN` to your bot token and `CLIENT_ID` to the Application ID.
5. Invite the bot with `bot` and `applications.commands` scopes and grant **Manage Channels** and **Manage Roles**. Do not grant Administrator.
6. Run `npm start` and keep it running.
7. In your Discord server, use `/setup`.

Never share your bot token or your `.env` file. If the old bot is already invited, use the same application/token and replace its running code with this project, then restart it.
